import React from "react";

const Jumbotron = ({ children }) => (
  <div className="title" align="center">
    <h1>Final Title</h1>
  </div>
);

export default Jumbotron;
