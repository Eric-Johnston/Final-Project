import React from "react";

const Nav = () => (
  <nav className="navbar navbar-default">
    <div className="container-fluid">
      <div className="navbar-header">
      </div>
    </div>
  </nav>
);

export default Nav;
